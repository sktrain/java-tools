package com.baeldung.jni.registernatives;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.baeldung.jni.RegisterNativesHelloWorldJNI;
;


public class JNIRegisterNativesManualTest {
    @BeforeAll
    public void setup() {
        System.loadLibrary("native");
    }

    @Test
    public void whenRegisteredNativeHelloWorld_thenOutputIsAsExpected() {
        RegisterNativesHelloWorldJNI helloWorld = new RegisterNativesHelloWorldJNI();
        helloWorld.register();

        String helloFromNative = helloWorld.sayHello();

        assertNotNull(helloFromNative);
        assertTrue(helloFromNative.equals("Hello from registered native C++ !!"));
    }
}
