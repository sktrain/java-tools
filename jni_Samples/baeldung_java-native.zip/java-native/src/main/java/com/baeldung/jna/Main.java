package com.baeldung.jna;

public class Main {
	
	public static void main(String[] args) {
		
	}
}