package com.tutego.jni;

public class StrLen {
  static {
    System.loadLibrary( "strlen" );
//    System.loadLibrary( "JNITest" );
  }

  public static native int strlen( String s );
}