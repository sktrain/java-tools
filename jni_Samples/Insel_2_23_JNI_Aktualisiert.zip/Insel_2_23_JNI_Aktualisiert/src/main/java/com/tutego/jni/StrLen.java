package com.tutego.jni;

public class StrLen {
  static {
//    System.loadLibrary( "strLen" );
//    System.loadLibrary( "JNITest" );
	  System.load("E:/stephan/workspaces/eclipse_workspaces/Java_PSI/Insel_2_23_JNI/strLen.dll");
  }

  public static native int strlen( String s );
}