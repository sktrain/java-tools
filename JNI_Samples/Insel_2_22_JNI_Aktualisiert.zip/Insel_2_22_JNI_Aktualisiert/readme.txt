Aktualisierte Variante von Christian Ullenboms Beispiel zu JNI:

Verwendet Java 17 (d.h. geänderte Bibliotheken des JDKs)