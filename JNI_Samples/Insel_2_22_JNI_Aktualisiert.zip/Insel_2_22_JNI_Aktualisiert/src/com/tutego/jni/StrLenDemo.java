package com.tutego.jni;

public class StrLenDemo {
	public static void main(String[] args) {
		//wo wird nach Libraries gesucht 
		System.out.println(System.getProperty("java.library.path"));
		
		
		System.out.println("Vor JNI");
		System.out.println(StrLen.strlen("2003 UB313"));
		System.out.println("Nach JNI");
		//System.out.println( StrLen.strlen( null ) );
	}
}