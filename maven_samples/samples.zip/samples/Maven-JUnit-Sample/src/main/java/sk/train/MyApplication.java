package sk.train;

public class MyApplication {

    public int getNumberOfThreads() {
        return 5;
    }

}