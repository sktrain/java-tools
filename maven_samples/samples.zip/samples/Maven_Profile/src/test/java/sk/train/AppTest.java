package sk.train;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
     /**
     * Rigourous Test :-)
     */
     @Test
     public void testApp()
    {
        App.main();
        assertTrue( true , "Fatal Error");
    }


}
