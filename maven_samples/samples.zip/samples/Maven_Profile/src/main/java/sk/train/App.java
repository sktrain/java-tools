package sk.train;

import java.util.ArrayList;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String... args )
    {
        Integer I = new Integer(1);

        System.out.println( "Hello World!" );
    }
}
