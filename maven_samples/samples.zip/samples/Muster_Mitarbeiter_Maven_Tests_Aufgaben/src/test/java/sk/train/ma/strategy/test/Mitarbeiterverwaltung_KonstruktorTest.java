package sk.train.ma.strategy.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import sk.train.ma.strategy.verwaltung.MitarbeiterVerwaltung;

class Mitarbeiterverwaltung_KonstruktorTest {

	/*
	Es sollte Folgendes getestet werden:
	- Konstruktor der MitarbeiterVerwaltung sollte nicht Null liefern
	- die interne Map sollte nicht Null sein
	- die interne Map sollte nicht leer sein
	 */


}
