package sk.train.ma.strategy.model;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Properties;

public interface Gehaltsmodell extends Serializable {
	
	public abstract BigDecimal getGehalt();

//	public static Gehaltsmodell getGehaltsmodell(String type) {
//		if (type.equals("A"))
//			return new ArbeiterModell(new BigDecimal((int)(Math.random()*100)),	new BigDecimal(120));
//		else return new FixGehaltModell(new BigDecimal((int)(Math.random()*10000))); }

}
