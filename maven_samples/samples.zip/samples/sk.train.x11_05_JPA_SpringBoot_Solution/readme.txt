JPA durch Spring gemanaged + deklarative Transaktionsunterstützung,
aber jetzt via SpringBoot realisiert: wir brauchen keine Konfig mehr für diesen Fall.
Nur noch die DB-Properties für Spring-Boot.

