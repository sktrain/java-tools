Ein Basis Maven Projekt mit aktuellen Plugin-Versionen vom Januar 2023
+ Jupiter-Dependencies
(erstellt auf Basis des Apache Maven Simple Archetype)
+ erweitert um Projekt-Report-Plugin für Site-Generierung