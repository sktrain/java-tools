JPA durch Spring gemanaged + deklarative Transaktionsunterstützung

setzt H2-Database mit HR-Schema voraus