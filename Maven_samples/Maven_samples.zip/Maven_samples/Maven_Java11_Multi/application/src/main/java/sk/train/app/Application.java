package sk.train.app;

import sk.train.service.Service;

public class Application {

	public static void main(String[] args) {

		System.out.println(Service.getMessage());
		

	}

}
