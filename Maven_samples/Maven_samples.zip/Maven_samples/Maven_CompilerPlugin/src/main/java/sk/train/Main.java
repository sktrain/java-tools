package sk.train;

import java.util.Date;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        System.out.println(new Date(2023, 1, 1));
    }
}